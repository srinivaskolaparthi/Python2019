print('Hi Python')
print("Hi Panda")
print('''Hi PYGO''')
"""
fsdffs
scaffolding
sdfsdfsd
"""