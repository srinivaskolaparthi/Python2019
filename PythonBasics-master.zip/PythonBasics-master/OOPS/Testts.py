class  parent:

    def  __init__(self):
        print("parent const")
    def  pp(self):
        print("parent")


class  child(parent):
    def  __init__(self):
        print("child const")

    def  cc(self):
        print("child")

c = child()
c.pp()
c.cc()

'''
got
output as: child
const
parent
child 
'''
