#() for inheritance
class Parent:
    def __init__(self):
        print("parent const")

    def pp(self):
        print("parent")

class Child (Parent):#single inheritance

    def __init__(self):
        print("child const")

    def cc(self):
        print("Child")


c = Child()
c.cc()
c.pp()