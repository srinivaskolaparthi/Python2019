for letter in 'Python':
   print ('Current Letter :', letter)

proj = ['Scope', 'RBS',  'Discover']
for proj1 in proj:
   print( 'Current proj :', proj1.upper())

   #----------------By Index
print("Index approach------------")
for index in range(len(proj)):#for(int a=0;a<12;a++)by ++3
       print('Current fruit :', proj[index])

for c in range(0,12,5):
   print(c)

#-------------------Inner
print('Lasttttttttttttttttttttttttttttttt')
for num in range(10,20):
   for i in range(2,num):
      if num%i == 0:
         j=num/i
         print ('%d equals %d * %d' % (num,i,j))
         break
   else:
      print( num, 'is a prime number')












