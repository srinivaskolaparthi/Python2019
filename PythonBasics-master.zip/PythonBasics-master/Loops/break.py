for letter in 'Kolaparthi':
   if letter == 'a':
      break
   print('Current Letter :', letter)