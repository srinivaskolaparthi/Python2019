for num in range(20,2,-2):
    print(num)