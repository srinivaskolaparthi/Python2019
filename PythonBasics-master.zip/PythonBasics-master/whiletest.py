x= range(0,100,2) # range(start,stop,step means increment or decrement based on signs)
for a in x:
    print(a)


    # display even no from 1 to 100

