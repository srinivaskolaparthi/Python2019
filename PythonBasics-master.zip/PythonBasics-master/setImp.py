my_set = {1,2,3,4,3,2}
my_set2 = {5,6,7,8}
print(my_set)
my_set.discard(1)
print(my_set)
print("-------")
print(my_set|my_set2)#like union
