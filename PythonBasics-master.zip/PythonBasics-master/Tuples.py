
tuple = [ 'Srini', 786 , 2.23, 'Scope', 70.2 ]
tinytuple = [123, 'Discover']

print(tuple)
print (tuple[0])
print (tuple[1:3])
print (tuple[2:])
print (tinytuple * 2)
print (tuple + tinytuple)