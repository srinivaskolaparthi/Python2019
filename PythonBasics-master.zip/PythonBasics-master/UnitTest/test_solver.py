import unittest
from UnitTest.ClassTEst import Solver

class TestSolver(unittest.TestCase):
    def test_negative_discr(self):
        s = Solver()

        self.assertRaises(Exception, s.demo, 2, 1, 2)

    def test_something(self):
        self.assertEqual(True, True)

    if __name__ == '__main__':
        unittest.main()