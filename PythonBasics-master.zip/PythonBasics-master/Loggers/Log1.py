import logging
logging.basicConfig(filename="sample.log", level=logging.INFO)
logging.info("Informational message")
