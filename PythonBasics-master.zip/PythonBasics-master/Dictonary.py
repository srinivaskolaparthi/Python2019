dict = {}
dict['one'] = "This is one"
dict[2]     = "This is two"

tinydict = {None: 'john','code':None, 'dept': 'sales'}
print(type(dict))
print(dict['one'])
print(dict[2])
print (tinydict)
print (tinydict.keys())
print (tinydict.values())