##Lists are like Arrays
lists = [ 'Srini', 'Willis' , 'AIA', 'Scope','coke' ]
tinylist = [123, 'Discover']
print (lists)
print (lists[2])
print (lists[1:3])
print (lists[2:0])
print (tinylist * 2)
print (lists + tinylist)
print(lists[2])
lists[3]='coco'
print(lists[2+1])

