import calendar
cal = calendar.prcal(2018)
print (cal)