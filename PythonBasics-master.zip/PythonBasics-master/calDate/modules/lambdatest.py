#lambda or ananamous
sum = lambda arg1, arg2: arg1 + arg2;
sub = lambda arg1, arg2: arg1 -arg2;

print("Value of total : ", sum(10, 20))
print("Value of total : ", sub(20, 20))