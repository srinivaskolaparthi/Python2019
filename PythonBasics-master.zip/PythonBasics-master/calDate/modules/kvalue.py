states ={
    'a':'aaa',
    'b':'bb'
}

for key,value in states.items():
    print(key,value)