#Any order we can maintain in parameters
def printinfo( name, age ):

   print ("Name: ", name)
   print ("Age ", age)
   return;


printinfo( age=12, name="kolaparthi" )