#default arguments
def printinfo(name="kolaparthi",age):#change order

   print ("Name: ", name)
   print ("Age ", age)
   return;


printinfo(age=90)