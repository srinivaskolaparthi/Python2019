def printme( str ):
   print(str)
   return;

printme("I'm first call to user defined function!")
printme("Again second call to the same function")