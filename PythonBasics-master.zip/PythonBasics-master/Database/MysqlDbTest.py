import pymysql

# Open database connection
db = pymysql.connect(host="127.0.0.1",port=3307,user ="root",passwd="mysql",
                     db="mysql" )

# prepare a cursor object using cursor() method
cursor = db.cursor()

# execute SQL query using execute() method.
cursor.execute("SELECT User from USER ")

# Fetch a single row using fetchone() method.
data = cursor.fetchone()
print ("Database version : %s " % data)

# disconnect from server
db.close()