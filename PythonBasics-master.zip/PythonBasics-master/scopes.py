'''
 # Scope will provide security to ur code
# security is divided into 2 categories.1)code level security
# 2) app level security
a =90 # global variable

def callme(inp):
    a1 = int (inp )# Local Scope
    return (a1+a)

inp =input("Please Enter Value:")
y = callme(inp)                           # calling a function
#print(a1)
print(y)

#===============================================

 write a program to pass set(all values in a set shld be dynamic values)
 as a parameter to a function.

u= {None} # Empty Set
u.add(input("Pls Enter"))
u.add(input("Enter2"))
print(u)

def display(u):
    for a in u:
      print(a)

display(u)
'''



u = {"name":"srini","desig":"SC","Comp":"capge"} # dictionary
print(u.keys())
print(u.values())
print(u.items()) #dictionary is used mainly in Networking/serialization/i18n













