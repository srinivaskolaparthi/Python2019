x = 5
print(callable(x))

def testFunction():
  print("call in Action")

y = testFunction
print(callable(y))