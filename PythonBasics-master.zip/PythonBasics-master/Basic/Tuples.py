tup1 = (12, 34.56)
tup2 = ('Srini', 'kola')
tup3 = tup1 + tup2
print (tup3)