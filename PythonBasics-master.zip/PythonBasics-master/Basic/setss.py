s = {22,33,33,556,878}
s.add(9876)
print(s)
s.remove(33)
print(s)
z = s.copy()
print(z)