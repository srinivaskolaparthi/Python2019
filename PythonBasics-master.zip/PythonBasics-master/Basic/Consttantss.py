class CONST(object):
    FOOT = 1234

    def __setattr__(self, *_):
        pass

CONST = CONST()

print (CONST.FOOT)    # 1234

CONST.FOOT = 4321
print (CONST.FOOT)
CONST.BAR = 5678