import sys
#print("No of Arguments",len(sys.argv)) #argv stands for variable no of arguments
#print (type (sys.argv[1]))
def Scope_UAT():
    print("UAT invoked")

def Scope_Prod():
    print("Prod invoked")

if sys.argv[1]=="UAT":
    Scope_UAT()
else:
    Scope_Prod()



