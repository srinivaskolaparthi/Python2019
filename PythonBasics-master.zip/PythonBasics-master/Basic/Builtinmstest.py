import sys
a = sys.builtin_module_names
print(a)