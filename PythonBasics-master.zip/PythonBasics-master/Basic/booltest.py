test = (77,0)
print(test,'is',bool(test))

print(type (test))


test = [0]
print(test,'is..',bool(test))

test = None
print(test,'is',bool(test))

test = True
print(test,'is',bool(test))

test = 'Easy Python'
print(test,'is',bool(test))