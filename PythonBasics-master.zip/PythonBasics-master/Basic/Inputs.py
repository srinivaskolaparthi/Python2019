ready=input('Insert')#https://docs.python.org/3/whatsnew/3.0.html
print(ready)

'''
Multiline comments
'''

#Single line comments