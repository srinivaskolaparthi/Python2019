a ="abcdefghijklmnopqrstuvwxyz"

print('%.2s' % a)