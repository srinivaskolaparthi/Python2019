import os
os.unlink("D:\\abc")