fo = open("b.txt", "r")

fo.write("Hii Srinivas")
fo.write("End of the file")
fo.close()